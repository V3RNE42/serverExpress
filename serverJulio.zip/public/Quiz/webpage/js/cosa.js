import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "https://www.gstatic.com/firebasejs/9.8.2/firebase-auth.js";
import {
  getDatabase,
  ref,
  onValue,
  set,
} from "https://www.gstatic.com/firebasejs/9.8.2/firebase-database.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.8.2/firebase-app.js";

/* ENUNCIADO PARTE 2 FIREBASE
Queremos añadir un desarrollo a nuestra app, que permita la siguiente funcionalidad:

- Lo primero que tendrá que aparecer será un login donde me pedirá correo y contraseña,
    también tendrá la opción de llevarme al formulario de registro

- El formulario de registro, deberá contemplar los siguiente datos:
    Nombre, edad, direccion, email, contraseña y otro campo para confirmar la contraseña.

- En caso de dar de alta el usuario correctamente debemos:
	- Dar de alta en nuestra base de datos al usuario con sus campos (nombre, edad,...)
    [PARA EL FINAL]
	- Mandar al usuario de vuelta al login

- Una vez logueado, deberíamos mostrar un mensaje personalizado al usuario con
    sus datos que anteriormente guardamos en la BBDD 
    [PARA EL FINAL]

- Debemos permitir al usuario salir del juego y volver al login */

window.addEventListener("load", eventos);

function eventos() {
  const app = initFirebase();
  const auth = getAuth(app);
  document.getElementById("register").addEventListener("click", (e) => {
    e.preventDefault();
    switchStyle();
  });
  document.getElementById("submitLogin").addEventListener("click", (e) => {
    e.preventDefault();
    loginUser(e, app);
  });
  document.getElementById("submitSignUp").addEventListener("click", (e) => {
    signUpUser(e, app);
  });
}

function switchStyle() {
  let loginForm = document.getElementById("loginForm");
  let signUp = document.getElementById("signUp");
  if (loginForm.style.display == "none" && signUp.style.display == "flex") {
    loginForm.style.display = "flex";
    signUp.style.display = "none";
  } else {
    loginForm.style.display = "none";
    signUp.style.display = "flex";
  }
}

// FUNCION DE LOGIN

function loginUser(e, app) {
  e.preventDefault();
  const auth = getAuth(app);
  const email = document.getElementById("user").value;
  const pass = document.getElementById("password").value;

  //funcion para loguearse
  signInWithEmailAndPassword(auth, email, pass)
    .then((response) => {
      //si login ha ido correctamente
      console.log("USER LOGUEADO CORRECTAMENTE");
      let ref = `users/${response._tokenResponse.localId}/`;
      let app = initFirebase();
      getData(app, ref);
    })
    .catch((error) => {
      console.log(error.code, error.message);
      window.alert("Usuario inválido o no registrado!");
    });
  }
  

// La siguiente función busca el ID de usuario en FireBase, lo saluda por pantalla, y se lo lleva al cuestionario
function getData(elem, reference) {
  const database = getDatabase(elem);
  const refQuestion = ref(database, reference);
  onValue(refQuestion, (snapshot) => {
    let data = snapshot.val();
    //Saludamos al usuario...
    window.alert(`¡Bienvenido ${data.name}!`);
    //...y nos lo llevamos al cuestionario
    window.location.assign("./QuizProject/home.html");
  });
}

// FUNCION CREAR USUARIO

function signUpUser(e, app) {
  e.preventDefault();
  console.log("entramos");
  let form = document.getElementById("signUp");
  let username = form.name.value;
  let email = form.mailSignUp.value;
  let pass = form.passwd1.value;
  let pass2 = form.passwd2.value;
  let auth = getAuth(app);

  const userData = {
    mail: email,
    password: pass,
    name: username,
  };

  if (pass !== "" && pass2 !== "" && pass === pass2) {
    createUserWithEmailAndPassword(auth, email, pass)
      .then((response) => {
        console.log(userData);
        userData.uid = response.user.uid;
        setUserDDBB(app, userData);
        console.log("Usuario creado correctamente", response);
        switchStyle();
      })
      .catch((error) => alert(error.code, error.message));
  } else {
    window.alert("las contraseñas no coinciden o están vacías!");
  }
}

async function setUserDDBB(app, userData) {
  const db = getDatabase(app);
  try {
    const response = await set(ref(db, "users/" + userData.uid), userData);
    console.log(
      `El usuario ${userData.name} se ha dado de alta en la base de datos`
    );
  } catch (e) {
    console.log("Error al dar de alta el usuario en la Base de Datos", e);
  }
}

function initFirebase() {
  const firebaseConfig = {
    apiKey: "AIzaSyB9mXUNAQoSaXzjX0Ot7xTAVI7xuSMbFJQ",
    authDomain: "proyectico-21532.firebaseapp.com",
    databaseURL:
      "https://proyectico-21532-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "proyectico-21532",
    storageBucket: "proyectico-21532.appspot.com",
    messagingSenderId: "906827652319",
    appId: "1:906827652319:web:02bba21d4532ee07a51d6a",
  };
  return initializeApp(firebaseConfig);
}
